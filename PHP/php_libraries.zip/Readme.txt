1 - Install composer from:
--------------------------
https://getcomposer.org/


2 - Create composer.json and add:
--------------------------------
{
  "require": {}
}


3 - Initialize packages folder:
-------------------------------
> composer install (at composer.json directory)


4 - Install new packages:
-------------------------
> composer require <package-name>



Laravel query builder documentation:
-----------------------------------
https://laravel.com/docs/5.8/queries

Laravel validation documentation:
---------------------------------
https://laravel.com/docs/5.8/validation