<?php
// show error and warnings
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// needed to use composer packages
include './packages/vendor/autoload.php';

// the packages used
use Illuminate\Database\Capsule\Manager as DB;
use Illuminate\Events\Dispatcher;
use Illuminate\Container\Container;

// database instance
$db = new DB;

// set connection
$db->addConnection([
    'driver'    => 'mysql',
    'host'      => 'localhost',
    'database'  => 'db_name',
    'username'  => 'user',
    'password'  => 'pass',
    // 'charset'   => 'utf8',
    // 'collation' => 'utf8_unicode_ci',
    // 'prefix'    => '',
]);

// Set the event dispatcher used by Eloquent models
$db->setEventDispatcher(new Dispatcher(new Container));

// Make this db instance available globally via static methods
// $db->setAsGlobal();

// Setup the Eloquent ORM
$db->bootEloquent();

// using query builder
$data = DB::table('table_name')->select('col1', 'col2')->get();
foreach($data as $row)
  echo $row->col1 . " ===> " . $row->col2 . "<br />";

// raw query
$data = DB::select('select col1, col2 from table_name');
foreach($data as $row)
  echo $row->col1 . " ===> " . $row->col2 . "<br />";